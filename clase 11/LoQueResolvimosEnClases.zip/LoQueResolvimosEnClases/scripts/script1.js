function procesar() {
  var numero = document.getElementById('numero').value;
}

// Chequear si el número ingresado se encuentra (0; 13]U[56; 89]
// function procesar() {
//   var numero = document.getElementById('numero').value;
//   if (numero > 0 && numero <= 13 || numero >= 56 && numero <= 89) {
//     console.log('El número es válido');
//   } else {
//     console.error('El número no es válido');
//   }
// }

// Chequear si el número ingresado es positivo, no hago nada si no es positivo.
// function procesar() {
//   var numero = document.getElementById('numero').value;
//   if (numero > 0) {
//     console.log('El numero es positivo');
//   }
// }

// Chequear si el número ingresado es mayor a 5000
// function procesar() {
//   var numero = document.getElementById('numero').value;
//   if (numero > 5000) {
//     console.log('El numero es mayor a 5000');
//   } else {
//     console.error('El numero es menor o igual a 5000');
//   }
// }

// Chequear si el número ingresado es igual a la palabra 'Acamica'
// function procesar() {
//   var numero = document.getElementById('numero').value;
//   if (numero == 'Acamica') {
//     console.log('La palabra es igual a Acamica');
//   } else {
//     console.error('La palabra no es igual a Acamica');
//   }
// }

// El anterior con toUpperCase()
// function procesar() {
//   var numero = document.getElementById('numero').value;
//   console.log(numero.toUpperCase());
//   if (numero.toUpperCase() == 'ACAMICA') {
//     console.log('La palabra es igual a Acamica');
//   } else {
//     console.error('La palabra no es igual a Acamica');
//   }
// }

// Condiciones nesteadas, si es un entero y mayor o igual a 5000
// function procesar() {
//   var numero = document.getElementById('numero').value;
//   if (Number.isInteger(parseInt(numero))) {
//     console.log(parseInt(numero));
//     if(numero >= 5000) {
//       console.log('el numero es mayor o igual a 5000');
//     } else {
//       console.log('es numero pero menor a 5000');
//     }
//   } else {
//     console.error('no es un entero');
//   }
// }

// Chequear si un numero es par o impar, usando la negación !
// function procesar() {
//   var numero = document.getElementById('numero').value;
//   if (!(numero % 2 == 0)) {
//     console.log('el numero es impar');
//   } else {
//     console.log('el numero es par');
//   }
// }
