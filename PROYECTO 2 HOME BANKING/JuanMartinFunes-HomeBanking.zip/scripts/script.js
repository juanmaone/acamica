//PROYECTO HOME BANKING
//OCTUBRE 2018
//HOME BANKING

//DECLARACIÓN DE VARIABLES

var nombreUsuario = 'juanma';
var saldoCuenta = 250000;
var limiteExtraccion = 20000;

//Funciones
/*extraerDinero
    depositarDinero
    pagarServicio
    transferirDinero
    cambiarLimiteDeExtraccion
*/

function extraerDinero() {

}

function depositarDinero() {

}

function pagarServicio() {

}

function transferirDinero() {

}

function cambiarLimiteDeExtraccion() {

}